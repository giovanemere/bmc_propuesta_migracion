# Core MCP Diagram Generator
